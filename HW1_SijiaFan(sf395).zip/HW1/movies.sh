#!/bin/bash 


echo $@ | grep -c 'v\|er\|an'