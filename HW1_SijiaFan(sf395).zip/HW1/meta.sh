#!/bin/bash 

#source: https://stackoverflow.com/questions/7301026/extract-numbers-from-filename


for filename in $(ls |grep 'p[0-9]\+.sh'); do
  time ./$filename
done

mkdir Outputs

#mv ‘find . -name “*.txt”’ Outputs


for filename in $(ls | grep '.*.txt'); do
    mv $filename Outputs
done