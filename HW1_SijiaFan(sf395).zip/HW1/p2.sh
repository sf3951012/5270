#!/bin/bash 

#http://www.robelle.com/smugbook/regexpr.html

if [ -z $@ ]; then 
  echo “created phone_data.txt with phone numbers” 
  grep -o '\(([0-9]\{3\})\|[0-9]\{3\}\)-\?[0-9]\{3\}-\?[0-9]\{4\}' data.txt > phone_data.txt;
else 
  Echo “created phone_$@“
  grep -o '\(([0-9]\{3\})\|[0-9]\{3\}\)-\?[0-9]\{3\}-\?[0-9]\{4\}' $@ > phone_$@; fi