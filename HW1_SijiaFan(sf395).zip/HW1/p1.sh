#!/bin/bash 
# use the pdf files given in boot camp as resources


if [ ! -f “data.txt” ]; then curl -OL https://people.orie.cornell.edu/bdg79/data.txt; fi

if [ -f “summary.txt” ]; then rm summary.txt; fi

head -5 data.txt > summary.txt
tail -5 data.txt >> summary.txt


